# my-boom-stick

This repository contains scripts to diagnose Windows issues and help schedule a Safe Mode boot.

## Installation

Install the required Python packages using pip:

```bash
pip install -r requirements.txt
```

## Running

Some commands require administrator privileges. Run the scripts from an elevated command prompt so tools like `bcdedit` can modify the boot configuration.

To see diagnostics without making changes, run:

```bash
python system_diagnostics.py
```

To schedule Safe Mode and apply the suggested changes, run:

```bash
python system_diagnostics.py --apply
```

Use `--apply` only after ensuring you have a current restore point or backup. You can cancel the Safe Mode boot with:

```bash
python undo_changes.py
```
