#!/usr/bin/env python3
import subprocess
import sys

if not sys.platform.startswith("win"):
    sys.exit("This script is intended for Windows systems only.")

def undo_safe_mode():
    result = subprocess.run(
        ["bcdedit", "/deletevalue", "{current}", "safeboot"],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print(f"Failed to remove Safe Mode flag: {result.stderr.strip()}")

if __name__ == "__main__":
    undo_safe_mode()
    print("Safe Mode boot flag removed. You can reboot normally.")
